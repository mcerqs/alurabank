const negociacao = new Negociacao(new Date(), 1, 100);

console.log('Negociação valor: ', negociacao.valor);